<?php
// DB 설정 - AWS 운영 환경 (127.0.0.1 명시적 설정)
return [
    'host' => '127.0.0.1',
    'db'   => 'jayeonbaram',
    'user' => 'bitnami',
    'pass' => 'Xi!R:yFGC4N6',
    'charset' => 'utf8mb4',
];
